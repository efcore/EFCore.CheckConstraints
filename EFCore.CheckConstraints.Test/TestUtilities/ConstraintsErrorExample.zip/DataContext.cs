using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Constraints
{
    /// <inheritdoc />
    public class DataContext : DbContext
    {
        public DataContext() { }

        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public static string ConnectionString { get; set; } = @"Data Source=(localdb)\MSSqlLocalDb;Initial Catalog=Test;Integrated Security=True";

        public virtual DbSet<Base> Base { get; set; }
        public virtual DbSet<Derived> Derived { get; set; }

        public static void ConfigureOptions(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
               .UseSqlServer(ConnectionString)
               .UseAllCheckConstraints();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("dbo");

            modelBuilder.Entity<Base>().ToTable("Bases").HasKey(t => t.Id);
            modelBuilder.Entity<Base>().Property(t => t.Id).ValueGeneratedOnAdd().IsRequired();

            modelBuilder.Entity<Derived>().ToTable("Deriveds");
            modelBuilder.Entity<Derived>().Property(t => t.E).IsRequired().HasDefaultValue(Enum1.A);
        }
    }

    public class DataContextFactory : IDesignTimeDbContextFactory<DataContext>
    {
        public DataContext CreateDbContext(string[] args)
        {
            DbContextOptionsBuilder<DataContext> optionsBuilder = new DbContextOptionsBuilder<DataContext>();
            DataContext.ConfigureOptions(optionsBuilder);
            return new DataContext(optionsBuilder.Options);
        }
    }
}
