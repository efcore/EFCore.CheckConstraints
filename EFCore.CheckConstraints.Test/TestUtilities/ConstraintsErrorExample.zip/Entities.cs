using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Constraints
{
    public class Base
    {
        [Key] [Required]
        public long Id { get; set; }
    }

    public class Derived : Base
    {
        public Derived()
        {
            E = Enum1.A;
        }

        [Required]
        public Enum1 E { get; set; }
    }

    public enum Enum1
    {
        A, B
    }
}
