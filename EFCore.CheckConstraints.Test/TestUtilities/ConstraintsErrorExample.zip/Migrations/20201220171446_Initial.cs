﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Constraints.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "Bases",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bases", x => x.Id);
                    table.CheckConstraint("CK_Deriveds_E_Enum", "[E] IN (0, 1)");
                });

            migrationBuilder.CreateTable(
                name: "Deriveds",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false),
                    E = table.Column<int>(type: "int", nullable: false, defaultValue: 0)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Deriveds", x => x.Id);
                    table.CheckConstraint("CK_Deriveds_E_Enum", "[E] IN (0, 1)");
                    table.ForeignKey(
                        name: "FK_Deriveds_Bases_Id",
                        column: x => x.Id,
                        principalSchema: "dbo",
                        principalTable: "Bases",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Deriveds",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Bases",
                schema: "dbo");
        }
    }
}
